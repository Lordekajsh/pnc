from typing import Union
from pyrogram import Client, filters
from pyrogram.errors import BadRequest
from pyrogram.types import CallbackQuery, InlineKeyboardButton, InlineKeyboardMarkup, Message
from database import cur, save
from utils import create_mention, get_info_wallet

bom_dia = "Bom dia!"

@Client.on_message(filters.command("texto"))
async def set_bom_dia(c: Client, m: Message):
    if m.from_user.id == YOUR_ADMIN_ID:
        global bom_dia
        text = m.text.split(maxsplit=1)
        if len(text) > 1:
            bom_dia = text[1]
            await m.reply("Frase 'bom dia' atualizada!")
        else:
            await m.reply(f"A frase atual de 'bom dia' é: {bom_dia}")

@Client.on_message(filters.private)
async def send_bom_dia(c: Client, m: Message):
    if m.from_user.id != YOUR_BOT_ID:
        return
    await m.reply(bom_dia)

@Client.on_message(filters.command(["start", "menu"]))
@Client.on_callback_query(filters.regex("^start$"))
async def start(c: Client, m: Union[Message, CallbackQuery]):
    user_id = m.from_user.id

    rt = cur.execute(
        "SELECT id, balance, balance_diamonds, refer FROM users WHERE id=?", [user_id]
    ).fetchone()

    if isinstance(m, Message):
        refer = (
            int(m.command[1])
            if (len(m.command) == 2)
            and (m.command[1]).isdigit()
            and int(m.command[1]) != user_id
            else None
        )

        if rt[3] is None:
            if refer is not None:
                mention = create_mention(m.from_user, with_id=False)

                cur.execute("UPDATE users SET refer = ? WHERE id = ?", [refer, user_id])
                try:
                    await c.send_message(
                        refer,
                        text=f"<b>O usuário {mention} se tornou seu referenciado.</b>",
                    )
                except BadRequest:
                    pass

    kb = InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton("💳 COMPRAR", callback_data="comprar_cc"),
                InlineKeyboardButton("💵 PIX AUTOMÁTICO", callback_data="add_saldo"),
            ],
            [
                InlineKeyboardButton("🪪 CARTEIRA", callback_data="user_info"),
                InlineKeyboardButton("🏆 DONO", url="https://t.me/SUPLINUX"),
            ],
            [
                InlineKeyboardButton(bom_dia, callback_data="bom_dia"),
                InlineKeyboardButton("💻 DEV", url="https://t.me/teslaofc"),
            ],
        ]
    )

    bot_logo, news_channel, support_user = cur.execute(
        "SELECT main_img, channel_user, support_user FROM bot_config WHERE ROWID = 0"
    ).fetchone()

    start_message = f"""<b>[ ]({bot_logo}) 🏆 | BEM VINDO {m.from_user.first_name} A MELHOR LOJA DE CCS DO MERCADO!!</b>
    
<b>✅ - PARA POR SALDO BASTA MANDAR NO CHAT /Pix 15!!</b>
<b>✅ - NÃO DAMOS REEMBOLSO!!</b>
<b>✅ - SALDO MÍNIMO PARA ADIÇÃO 10!!</b>

<b>👤 | [SUPORTE](https://t.me/HECSTECH)</b>
<b>👥 | [GRUPO](https://t.me/HECSTECH)</b>
<b>🧠 | [CANAL](https://t.me/HECSTECH)</b>

<b>🛍 - SALDO EM DOBRO: ATIVO</b>
    
{get_info_wallet(user_id)}"""

    if isinstance(m, CallbackQuery):
        send = m.edit_message_text
    else:
        send = m.reply_text
    save()
    await send(start_message, reply_markup=kb)
